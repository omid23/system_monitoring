import pickle
import socket
import psutil

import numpy as np

def Main():
    port = 5000
    mySocket = socket.socket()
    mySocket.bind(('', port))
    mySocket.listen(5)
    conn, addr = mySocket.accept()
    print("Connection from: " + str(addr))
    a = np.array([])
    while True:
        a = np.append(a, psutil.cpu_percent(interval=0.01))
        conn.send(pickle.dumps(a))
        data = conn.recv(1024).decode()
        if not data:
            break
    conn.close()


if __name__ == '__main__':
    Main()
