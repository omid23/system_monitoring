import psutil
import numpy as np
import matplotlib.pyplot as plt

a = np.array([])
while True:
    a = np.append(a, psutil.cpu_percent(interval=0.01))
    plt.pause(1)
    plt.plot(a)
