1) username and password of both servers --> main, 1234
2) firewall ip --> it is dhcp, so check ifconfig
3) change overflow_requests.py ip address
4) run 192.168.1.10:19999 for system monitoring
5) enable or disable --> sudo service netdata start