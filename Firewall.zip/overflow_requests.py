import threading
import time
import matplotlib.pyplot as plt
import numpy as np
import requests


# http://192.168.1.4 --> firewall
# http://192.168.1.6 --> main server

class RequestThread(threading.Thread):
    def __init__(self, idx, request_number):
        super().__init__()

        self.idx = idx
        self.request_number = request_number
        self.time_average_of_each_request = 0

    def run(self):
        """

        :rtype: float
        """
        start_time = time.time()
        for _ in range(self.request_number):
            requests.get("http://192.168.1.10")

        bulk_request_duration = time.time() - start_time
        time_average_of_each_request = (time.time() - start_time) / self.request_number
        # print("%2d: %f" % (self.idx, time.time() - start_time))
        # self.time_average_of_each_request = time_average_of_each_request
        return time_average_of_each_request


print('how many threads are u lookin for ?!')
thread_number = int(input())
print('so your starting thread number would be ... ?!')
init_num_thread = int(input())
time_array = np.array([])
avg_time = 0
thread_array = np.array([])
for tn in range(init_num_thread, thread_number):
    for i in range(tn):
        r = RequestThread(i, 1000)
        multiplied_single_request_response_duration = r.run() * 1000
        single_request_response_duration = float("{0:.2f}".format(multiplied_single_request_response_duration))
        avg_time += single_request_response_duration
        r.start()

    time_array = np.append(time_array, avg_time / tn)
    thread_array = np.append(thread_array, tn)


# add_zero = time_array.shape[0] - thread_array.shape[0]
# thread_array = np.append(thread_array, np.zeros(add_zero))
# thread_array.reshape(time_array.shape)


plt.plot(time_array, thread_array)
plt.ylabel('Number of Requests')
plt.xlabel('Time')
plt.title("Requesting Time")
plt.show()

if __name__ == '__main__':
    print("done!")
