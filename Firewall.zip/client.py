import pickle

import matplotlib.pyplot as plt
import socket


def Main():
    host = '192.168.1.7'
    # host = '127.0.0.1'
    port = 5000

    mySocket = socket.socket()
    mySocket.connect((host, port))

    # message = input(" -> ")

    while True:
        mySocket.send('a'.encode())
        data = mySocket.recv(1024)
        data_arr = pickle.loads(data)
        plt.pause(1)
        plt.plot(data_arr)
    # mySocket.close()


if __name__ == '__main__':
    Main()
